## v1.1.0:

* fix bug caused by the removal of `mysql_database` LWRP from the mysql cookbook starting with version 1.2.0
* fix most foodcritic warnings
* upgrade to the latest stable branch for drush: 7.x-5.4
* installing by default latest stable drupal version 7.14

## v1.0.0:

* dropping support for drupal6.x; this requires drupal7 for the install to work
